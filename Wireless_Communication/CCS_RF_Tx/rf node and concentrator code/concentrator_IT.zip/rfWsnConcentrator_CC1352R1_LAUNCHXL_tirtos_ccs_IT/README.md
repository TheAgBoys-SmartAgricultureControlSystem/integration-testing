Example Summary
---------------
The WSN Concentrator example illustrates how to create a simple Wireless Sensor
Network Concentrator device which listens for packets from other nodes. This
example is meant to be used together with the WSN Node example to form a one-
to-many network where the nodes send messages to the concentrator.

This examples showcases the use of several Tasks, Semaphores and Events to
receive packets, send acknowledgments and display the received data on the
LCD. For the radio layer, this example uses the EasyLink API which provides
an easy-to-use API for the most frequently used radio operations.

Refer to [EasyLink API](http://processors.wiki.ti.com/index.php/SimpleLink-EasyLink)
for more information on the EasyLink API.


Peripherals Exercised
---------------
* `Board_PIN_LED0` - Toggled when data is received over the RF interface

System Confirguration Tool (SysConfig) Setup
-------------
### Driver Configuration
* `RF` - RF Driver Configuration
    * Hardware Used - `RF Antenna Switch`
* `Power` - Power Manager Configuration
    * Default options used
* `GPIO` - GPIO Configuration
    * Hardware Used - `LaunchPad LED Red`
* `GPIO` - GPIO Configuration
    * Hardware Used - `LaunchPad LED Green`
* `Display` - Display Configuration
    * Hardware Used - `XDS110 UART`
* `Display` - Display Configuration
    * Hardware Used - `Sharp LCD Display (BOOSTXL-SHARP128)`

### EasyLink Stack Configuration
* `Basic Configuration` - Basic EasyLink Stack Configuration
    * Enable Address Filtering - `True`
    * Addresses to Filter - `0x00`
* `RF Settings` - PHY Configuration
    * Default PHY - `Custom`
    * Additional Supported PHYs - `Custom`

Resources & Jumper Settings
---------------

> If you're using an IDE (such as CCS or IAR), please refer to Board.html in your project
directory for resources used and board-specific jumper settings. Otherwise, you can find
Board.html in the directory &lt;SDK_INSTALL_DIR&gt;/source/ti/boards/&lt;BOARD&gt;.

## Board Specific Settings
1. The WSN examples use the custom physical mode by default, which sets
the center frequency to:
    - 433.92 MHz for the CC1350-LAUNCHXL-433
    - 433.92/490 MHz for the CC1352P-4-LAUNCHXL
    - 2440 MHz on the CC2640R2-LAUNXHL
    - 868.0 MHz for other launchpads
In order to change frequency, modify the smartrf_settings.c file. This can be
done using the code export feature in Smart RF Studio, or directly in the file
2. On the CC1352P1 the high PA is enabled (high output power) for all
Sub-1 GHz modes by default.
3. On the CC1352P-2 the high PA operation for Sub-1 GHz modes is not supported
4. On the CC1352P-4 the high PA is enabled (high output power) for all
Sub-1 GHz modes by default.
    - The center frequency for 2-GFSK is set to 490 MHz
    - **CAUTION:** The center frequency for SimpleLink long range (SLR) is set to 433.92 MHz,
    but the high output power violates the maximum power output requirement
    for this band
5. The CC2640R2 is setup to run all proprietary physical modes at a center
frequency of 2440 MHz, at a data rate of 250 Kbps

Example Usage
---------------
Run the example. On another board (or several boards) run the WSN Node example.
The LCD will show the discovered node(s). When the collector receives data from
a new node, it is given a new row on the display and the received value is shown.
If more than 7 nodes are detected, the device list rolls over, overriding
the first. Whenever an updated value is received from a node, it is updated on
the LCD display.

Application Design Details
---------------
This examples consists of two tasks, one application task and one radio
protocol task.

The ConcentratorRadioTask handles the radio protocol. This sets up the EasyLink
API and uses it to always wait for packets on a set frequency. When it receives
a valid packet, it sends an ACK and then forwards it to the ConcentratorTask.

The ConentratorTask receives packets from the ConcentratorRadioTask, displays
the data on the LCD and toggles Board_PIN_LED0.

*RadioProtocol.h* can also be used to change the
PHY settings to be either the default IEEE 802.15.4g 50kbit,
Long Range Mode or custom settings. In the case of custom settings,
the *smartrf_settings.c* file is used. This can be changed either
by exporting from Smart RF Studio or directly in the file.

Note for IAR users: When using the CC1310DK, the TI XDS110v3 USB Emulator must
be selected. For the CC1310_LAUNCHXL, select TI XDS110 Emulator. In both cases,
select the cJTAG interface.

EasyLink Stack Configuration using the System Configuration Tool (SysConfig)
-------------------------
### Overview
The purpose of SysConfig is to provide an easy to use interface for configuring
drivers, RF stacks, and more. Many parameters of the EasyLink stack can be
configured using SysConfig including address filtering, clear channel
assessment parameters, RF settings, and advanced settings.

### Basic Configuration
The basic EasyLink stack configuration includes address filtering, address
size, and max data length. When these paramters are configured via SysConfig,
they will take affect when the EasyLink_init() API is called.

### Clear Channel Assessment (CCA) Configuration
The CCA configuration parameters are used when checking if a channel is clear
of traffic before transmitting. The combination of RSSI threshold and channel
idle time define what is considered a "clear" channel. The max and min backoff
window, backoff time units, and random number generation function define the
behavior when the channel is sniffed and found to be busy. The CCA
configuration parameters take affect when using the EasyLink_transmitCcaAsync()
API.

### Advanced Configuration
The advanced configuration parameters require in-depth knowledge of the
EasyLink APIs. For more information on these configuration parameters please
see the EasyLink_CtrlOption enumeration for use with the EasyLink_setStrl() API.
When the advanced configuration parameters are configured via SysConfig, they
take affect when the EasyLink_init() API is called with the exception of the
Asynchronous Rx Timeout (ms) and the Test Mode Whitening paramters. These
require the use of the EasyLink_receiveAsync() and EasyLink_setCtrl() APIs
respectively.

### RF Configuration
The RF configuration of the EasyLink stack includes setup of both the RF driver
and any PHYs the application needs to support. The RF Driver provides access to
the radio core and offers a high-level interface for command execution that is
utilized by the EasyLink APIs. Configuration of the PHY settings includes
selecting the default PHY that will be used when the EasyLink_init() API is
called as well as any additional supported PHYs. As each PHY is added to the
configuraiton a Radio Configuration module will provide the ability to
customize settings such as frequency, power, etc. All the RF configuration
parameters take affect when calling the EasyLink_init() API.

### Responsibilities of the Application
Several EasyLink stack parameters configured in SysConfig require the
application to use specific EasyLink APIs to take affect. The following table
shows which parameters that require the use of these APIs in the application.

    | Configuration Parameter(s)          | EasyLink API needed to take Affect                 |
    |-------------------------------------|----------------------------------------------------|
    | All parameters                      | EasyLink_init()                                    |
    | Clear Channel Assessment Parameters | EasyLink_transmitCcaAsync()                        |
    | Asynchronous Rx Timeout (ms)        | EasyLink_receiveAsync()                            |
    | Test Mode Whitening                 | EasyLink_setCtrl()                                 |

### Provided SysConfig Files
The .syscfg file provided with an EasyLink stack example project has been
configured and tested with that project. Changes to the .syscfg file can and
will alter the behavior of the example. Some stack parameters configured in
SysConfig will require the use of specific EasyLink APIs to take affect. Please
refer to the Responsibilities of the Application section of this document for
further information on which configuration parameters require the use of
specifc APIs.
