/*
 * Copyright (c) 2018, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== display.c ========
 */
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* TI-Drivers Header files */
#include <ti/drivers/GPIO.h>

/* Display Header files */
#include <ti/display/Display.h>
#include <ti/display/DisplayUart.h>
#include <ti/display/DisplayExt.h>
#include <ti/display/AnsiColor.h>

/* Board Header files */
#include "Board.h"

int nodeid = 0;
int rssi = 0;
float lat = 0;
float lng = 0;
int soil = 0;

int random_int(int lower, int upper, int count)
{
    int i;
    for (i = 0; i < count; i++) {
        int num = (rand() %
           (upper - lower + 1)) + lower;
        return num;
    }
    return 0;
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    GPIO_init();
    Display_init();

    GPIO_write(Board_GPIO_LED0, Board_GPIO_LED_ON);

    /* Initialize display and try to open both UART and LCD types of display. */
    Display_Params params;
    Display_Params_init(&params);
    params.lineClearMode = DISPLAY_CLEAR_BOTH;

    /* Open both an available LCD display and an UART display.
     * Whether the open call is successful depends on what is present in the
     * Display_config[] array of the board file.
     */
    Display_Handle hLcd = Display_open(Display_Type_LCD, &params);
    Display_Handle hSerial = Display_open(Display_Type_UART, &params);

    if (hSerial == NULL && hLcd == NULL) {
        /* Failed to open a display */
        while (1) {}
    }

    /* Check if the selected Display type was found and successfully opened */
    if (hSerial) {
        Display_printf(hSerial, 0, 0, "Hello Serial!");
    }
    else
    {
        /* Print unavail message on LCD. Note it's not necessary to
         * check for NULL handles with Display APIs, so just assume hLcd works.
         */
        Display_printf(hLcd, 4, 0, "Serial display");
        Display_printf(hLcd, 5, 0, "not present");
        sleep(1);
    }

    /* Loop forever, alternating LED state and Display output. */
    while (1) {

        /* Print to UART */
        nodeid = 0; // node id
        rssi = -100;  // rssi can be from noise floor to 0
        lat = -105.260; // DLC building
        lng = 40.010; // DLC building
        soil = random_int(0, 4095, 1); // percentage from 0 to 4095
        Display_printf(hSerial,  0, 0, "\033[2J\033[HNodeId:%d#SoilMoisture:%d#Latitude:%0.2f#Longitude:%0.2f#RSSI:%d\n", nodeid, soil, lat, lng, rssi);

        sleep(5);

        nodeid = 1; // node id
        rssi = -101;  // rssi can be from noise floor to 0
        lat = -105.260; // DLC building
        lng = 40.010; // DLC building
        soil = random_int(0, 4095, 1); // percentage from 0 to 4095
        Display_printf(hSerial,  0, 0, "\033[2J\033[HNodeId:%d#SoilMoisture:%d#Latitude:%0.2f#Longitude:%0.2f#RSSI:%d\n", nodeid, soil, lat, lng, rssi);

        sleep(5);

        nodeid = 2; // node id
        rssi = -101;  // rssi can be from noise floor to 0
        lat = -105.260; // DLC building
        lng = 40.010; // DLC building
        soil = random_int(0, 4095, 1); // percentage from 0 to 4095
        Display_printf(hSerial,  0, 0, "\033[2J\033[HNodeId:%d#SoilMoisture:%d#Latitude:%0.2f#Longitude:%0.2f#RSSI:%d\n", nodeid, soil, lat, lng, rssi);

        sleep(5);

        nodeid = 3; // node id
        rssi = -101;  // rssi can be from noise floor to 0
        lat = -105.260; // DLC building
        lng = 40.010; // DLC building
        soil = random_int(0, 4095, 1); // percentage from 0 to 4095
        Display_printf(hSerial,  0, 0, "\033[2J\033[HNodeId:%d#SoilMoisture:%d#Latitude:%0.2f#Longitude:%0.2f#RSSI:%d\n", nodeid, soil, lat, lng, rssi);

        sleep(5);

        /* Toggle LED */
        GPIO_toggle(Board_GPIO_LED0);
    }
}
